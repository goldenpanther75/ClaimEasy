const fs = require('fs');
const path = require('path');

const EMAILS_FILE = path.join(__dirname, '../data/emails.json');

const sendEmail = (to, subject, body, type = 'Notification') => {
    try {
        let emails = [];
        if (fs.existsSync(EMAILS_FILE)) {
            const data = fs.readFileSync(EMAILS_FILE);
            emails = JSON.parse(data);
        }

        const newEmail = {
            id: 'EMAIL-' + Date.now(),
            to,
            subject,
            body,
            type,
            sentAt: new Date().toISOString(),
            status: 'Sent (Simulated)'
        };

        emails.unshift(newEmail); // Add to top

        // Keep only last 100 emails
        if (emails.length > 100) emails = emails.slice(0, 100);

        fs.writeFileSync(EMAILS_FILE, JSON.stringify(emails, null, 2));
        console.log(`[Email Simulation] Sent to ${to}: ${subject}`);
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

module.exports = { sendEmail };

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const configFile = path.join(__dirname, '../data/config.json');

// Helper to read configuration
const readConfig = () => {
    try {
        if (!fs.existsSync(configFile)) {
            // Default structure if file is missing
            return {
                logoUrl: "",
                heroConfig: { coverage: "₹5 Cr", price: "₹490" },
                customSections: []
            };
        }
        return JSON.parse(fs.readFileSync(configFile, 'utf8'));
    } catch (err) {
        console.error("Read Config Error:", err);
        return {};
    }
};

// Helper to write configuration
const writeConfig = (data) => {
    try {
        fs.writeFileSync(configFile, JSON.stringify(data, null, 2));
        return true;
    } catch (err) {
        console.error("Write Config Error:", err);
        return false;
    }
};

// GET /api/config - Public route to fetch configuration
router.get('/', (req, res) => {
    const config = readConfig();
    res.json(config);
});

// POST /api/admin/config/update - Admin route to update configuration
router.post('/update', (req, res) => {
    const adminEmail = req.headers['x-admin-email'];
    const role = req.headers['x-role'];

    // Verify simple admin role (matching admin.js logic)
    if (role !== 'admin') {
        return res.status(403).json({ error: "Access Denied. Admins only." });
    }

    const { category, data } = req.body;
    let config = readConfig();

    if (category === 'global') {
        // Update top level keys like logo
        config = { ...config, ...data };
    } else if (category === 'heroConfig') {
        config.heroConfig = { ...config.heroConfig, ...data };
    } else if (category === 'customSections') {
        // data should be an array of sections
        config.customSections = data;
    } else {
        return res.status(400).json({ error: "Invalid category" });
    }

    if (writeConfig(config)) {
        // Optionally log this action in logs.json
        try {
            const logsFile = path.join(__dirname, '../data/logs.json');
            let logs = [];
            if (fs.existsSync(logsFile)) {
                logs = JSON.parse(fs.readFileSync(logsFile, 'utf8'));
            }
            logs.unshift({
                id: "LOG" + Date.now(),
                action: "UPDATE_CONFIG",
                performedBy: adminEmail || 'Admin',
                details: `Updated config category: ${category}`,
                timestamp: new Date().toISOString()
            });
            fs.writeFileSync(logsFile, JSON.stringify(logs.slice(0, 500), null, 2));
        } catch (e) {
            console.error(e);
        }

        res.json({ success: true, message: "Configuration Updated", config });
    } else {
        res.status(500).json({ error: "Failed to save configuration" });
    }
});

module.exports = router;

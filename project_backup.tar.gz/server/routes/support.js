const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/cancellations.json');

// Helper to read data
const readData = () => {
    if (!fs.existsSync(DATA_FILE)) return [];
    const data = fs.readFileSync(DATA_FILE);
    return JSON.parse(data);
};

// Helper to write data
const writeData = (data) => {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};

// POST /api/support/cancel-policy
router.post('/cancel-policy', (req, res) => {
    try {
        const { policyNumber, policyType, reason, details, email } = req.body;

        if (!policyNumber || !reason || !email) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const cancellations = readData();

        const newRequest = {
            id: 'CAN-' + Date.now(),
            policyNumber,
            policyType,
            reason,
            details: details || '',
            email,
            status: 'Pending',
            createdAt: new Date().toISOString()
        };

        cancellations.push(newRequest);
        writeData(cancellations);

        res.status(201).json({
            message: 'Cancellation request submitted successfully',
            referenceId: newRequest.id
        });

    } catch (error) {
        console.error('Error submitting cancellation:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const claimsFile = path.join(__dirname, '../data/claims.json');

// --- Helper: Read JSON ---
const getClaims = () => {
    try {
        if (!fs.existsSync(claimsFile)) return [];
        return JSON.parse(fs.readFileSync(claimsFile, 'utf8'));
    } catch (err) { return []; }
};

// POST /api/chat - Chatbot interaction
router.post('/', async (req, res) => {
    try {
        const { message, context } = req.body; // Context contains page info
        const cleanMsg = message.trim().toLowerCase();

        // --- Context Awareness Check ---
        let contextHint = '';
        if (context && context.page) {
            if (context.page.includes('car')) contextHint = 'car';
            if (context.page.includes('bike')) contextHint = 'bike';
            if (context.page.includes('health')) contextHint = 'health';
            if (context.page.includes('travel')) contextHint = 'travel';
            if (context.page.includes('term')) contextHint = 'term';
        }

        // --- Intent: Quote / Buy (Contextual) ---
        if (cleanMsg.includes('quote') || cleanMsg.includes('buy') || cleanMsg.includes('price')) {
            let product = contextHint || 'insurance';
            // If user explicitly mentions a product, override context
            if (cleanMsg.includes('car')) product = 'car';
            if (cleanMsg.includes('bike')) product = 'bike';
            if (cleanMsg.includes('health')) product = 'health';
            if (cleanMsg.includes('travel')) product = 'travel';
            if (cleanMsg.includes('term')) product = 'term';

            const links = {
                'car': 'car_insurance.html',
                'bike': 'bike_insurance.html',
                'health': 'health_insurance.html',
                'travel': 'travel_insurance.html',
                'term': 'TermLife.html',
                'insurance': 'index.html'
            };

            return res.json({
                response: `I can help you get a <strong>${product} insurance</strong> quote.
                 <br><br>
                 <a href="${links[product] || 'index.html'}" class="chat-chip" style="display:inline-block; text-align:center;">Get ${product} Quote</a>`
            });
        }

        // --- Intent: File Claim ---
        if (cleanMsg.includes('file') || cleanMsg.includes('new claim') || cleanMsg.includes('register claim')) {
            return res.json({
                response: `To file a new claim, please visit our <strong>Claim Assistance</strong> page.
                <br><br>
                <div class="chat-options">
                    <a href="health_easyclaim.html" class="chat-chip">File Health Claim</a>
                    <a href="car_easyclaim.html" class="chat-chip">File Car Claim</a>
                    <a href="claim_intimation.html" class="chat-chip">Other Claims</a>
                </div>`
            });
        }

        // --- Intent: Check Status (with ID) ---
        // Match: CLM123, clm 123, claim id 123
        const idMatch = cleanMsg.match(/(?:clm|claim id)[\s-]*(\d+)/i);

        if (idMatch) {
            const numericId = idMatch[1];
            // Admin/Claims APIs generate IDs like "CLM" + Date.now() (e.g., CLM170000...)
            // We search for that exact string.
            const targetId = `CLM${numericId}`;

            const claims = getClaims();

            // Search: Exact Match or if user provided loose ID
            // Also handle case where user typed "CLM-123" but we store "CLM123"
            const claim = claims.find(c => c.id === targetId || c.id === `CLM-${numericId}` || c.id === numericId);

            if (claim) {
                let statusColor = 'orange';
                if (claim.status === 'Approved') statusColor = 'green';
                if (claim.status === 'Rejected') statusColor = 'red';
                if (claim.status === 'Settled') statusColor = '#0065ff';

                return res.json({
                    response: `Here are the details for <strong>${claim.id}</strong>:<br>
                    <div style="background:#f5f5f5; padding:10px; border-radius:8px; margin-top:5px;">
                        Status: <span style="color:${statusColor}; font-weight:bold">${claim.status}</span><br>
                        Amount: <strong>₹${claim.amount || 'N/A'}</strong><br>
                        Date: ${new Date(claim.submittedAt || claim.createdAt).toLocaleDateString()}
                    </div>`
                });
            } else {
                return res.json({
                    response: `I couldn't find a claim with ID <strong>${targetId}</strong>.<br>Please check the ID and try again, or contact support.`
                });
            }
        }

        // --- Intent: Check Status (without ID) ---
        if (cleanMsg.includes('status') || cleanMsg.includes('track')) {
            return res.json({
                response: "I can check that for you. Please provide your <strong>Claim ID</strong> (e.g., CLM123456)."
            });
        }

        // --- Intent: Support/Help ---
        if (cleanMsg.includes('help') || cleanMsg.includes('support') || cleanMsg.includes('contact')) {
            return res.json({
                response: "Our support team is available 24/7.<br>📞 <strong>1800-258-5956</strong><br>📧 <strong>care@claimeasy.com</strong>"
            });
        }

        // --- Default / Greeting ---
        if (cleanMsg.includes('hi') || cleanMsg.includes('hello')) {
            return res.json({
                response: "Hello! I am your ClaimEasy Assistant. How can I help you today?",
                showOptions: true // Frontend can check this to show standard chips
            });
        }

        // Fallback
        return res.json({
            response: "I understand simple requests like:<br>• 'File a claim'<br>• 'Check status of CLM123...'<br>• 'Contact Support'"
        });

    } catch (error) {
        console.error("Chatbot Error:", error);
        res.status(500).json({ error: "Server error." });
    }
});

module.exports = router;

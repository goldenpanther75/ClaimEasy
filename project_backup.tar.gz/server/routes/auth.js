const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const usersFilePath = path.join(__dirname, '../data/users.json');

// Temporary storage for OTPs (in memory)
const otpStore = {};

// Helper to read users
const getUsers = () => {
    try {
        const data = fs.readFileSync(usersFilePath, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        return [];
    }
};

// Helper to save users
const saveUsers = (users) => {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
};

// Generate and Send OTP
router.post('/send-otp', (req, res) => {
    const { identifier } = req.body; // Phone or Email

    if (!identifier) {
        return res.status(400).json({ message: 'Identifier (phone or email) is required' });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Store OTP with expiration (5 minutes)
    otpStore[identifier] = {
        otp,
        expires: Date.now() + 5 * 60 * 1000
    };

    console.log(`============================================`);
    console.log(`OTP for ${identifier}: ${otp}`);
    console.log(`============================================`);

    res.json({ message: 'OTP sent successfully', success: true });
});

// Verify OTP
router.post('/verify-otp', (req, res) => {
    const { identifier, otp } = req.body;

    if (!identifier || !otp) {
        return res.status(400).json({ message: 'Identifier and OTP are required' });
    }

    const storedData = otpStore[identifier];

    if (!storedData) {
        return res.status(400).json({ message: 'OTP not requested or expired', success: false });
    }

    if (Date.now() > storedData.expires) {
        delete otpStore[identifier];
        return res.status(400).json({ message: 'OTP expired', success: false });
    }

    if (storedData.otp !== otp) {
        return res.status(400).json({ message: 'Invalid OTP', success: false });
    }

    // OTP Verified. Check if user exists.
    const users = getUsers();
    const existingUser = users.find(u => u.phone === identifier || u.email === identifier);

    // Clear OTP after success
    delete otpStore[identifier];

    if (existingUser) {
        return res.json({
            success: true,
            isNewUser: false,
            user: existingUser,
            token: 'mock-jwt-token-' + Date.now()
        });
    } else {
        return res.json({
            success: true,
            isNewUser: true,
            token: 'mock-temp-token-' + Date.now()
        });
    }
});

// Register User
router.post('/register', (req, res) => {
    const { name, phone, email, dob, gender, address } = req.body;

    if (!name || (!phone && !email)) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    const users = getUsers();

    // Check duplication
    const duplicate = users.find(u => (phone && u.phone === phone) || (email && u.email === email));
    if (duplicate) {
        return res.status(400).json({ message: 'User already exists', success: false });
    }

    const newUser = {
        id: Date.now().toString(),
        name,
        phone,
        email,
        dob,
        gender,
        address, // Save address object
        createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    res.json({
        success: true,
        user: newUser,
        message: 'Registration successful'
    });
});

module.exports = router;

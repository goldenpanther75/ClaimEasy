const nodemailer = require('nodemailer');

// Configure the transporter with your Gmail
// You must set these environment variables to send real emails
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER, // e.g. your admin gmail
        pass: process.env.EMAIL_PASS  // e.g. your 16-character App Password
    }
});

const sendEmail = async (to, subject, body, type = 'Notification') => {
    try {
        if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
            console.warn('[Email Simulation] Please set EMAIL_USER and EMAIL_PASS to send real emails.');
            console.log(`[Email Simulation] Sent to ${to}: ${subject}`);
            return true;
        }

        const mailOptions = {
            from: `"ClaimEasy Admin" <${process.env.EMAIL_USER}>`,
            to: to,
            subject: subject,
            text: body
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`[Real Email] Sent to ${to}: ${info.messageId}`);
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

module.exports = { sendEmail };

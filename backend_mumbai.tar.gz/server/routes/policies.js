const express = require('express');
const router = express.Router();
const { createPolicy, getPolicies } = require('../services/dynamoService');
const { sendWhatsAppNotification } = require('../services/notificationService');
const { sendEmail } = require('../services/emailService');

const { createPolicyDB, getAllPoliciesDB } = require('../services/awsService');

// POST /api/policies - Create a new policy application
router.post('/', async (req, res) => {
    try {
        const policyData = req.body;
        // Save to AWS DynamoDB
        const dbResult = await createPolicyDB(policyData);

        // Send WhatsApp Notification (Simulation)
        if (policyData.mobile) {
            const message = `Dear ${policyData.fullName || 'User'}, your policy ${dbResult.policyId} has been successfully created. Download it from your dashboard.`;
            await sendWhatsAppNotification(policyData.mobile, message);
        }

        // Send Email Notification (Simulation)
        if (policyData.email) {
            const subject = `Policy Document - ${dbResult.policyId}`;
            const body = `Dear ${policyData.fullName || 'User'},<br><br>Your policy has been issued successfully.<br>Policy Number: ${dbResult.policyId}<br>Plan: ${policyData.planName || 'Insurance Plan'}<br><br>Thank you for choosing ClaimEasy.`;
            sendEmail(policyData.email, subject, body, 'Policy Issuance');
        }

        res.status(201).json({ ...dbResult, notificationSent: true });
    } catch (error) {
        console.error("Error in policy creation:", error);
        res.status(500).json({ error: error.message });
    }
});

// POST /api/policies/verify - Verify policy details for claim
router.post('/verify', (req, res) => {
    const { policyNumber, mobile } = req.body;

    if (!policyNumber || !mobile) {
        return res.status(400).json({ success: false, message: "Policy Number and Mobile are required" });
    }

    // Fetch all policies from DynamoDB first
    getAllPoliciesDB()
        .then(policies => {
            // Check for match (Loose comparison for robustness)
            const policy = policies.find(p =>
                (p.policyId === policyNumber || p.policyId === policyNumber.trim()) &&
                (p.mobile === mobile || p.mobile === mobile.trim())
            );

            if (policy) {
                res.json({ success: true, message: "Policy Verified", holderName: policy.fullName });
            } else {
                res.status(404).json({ success: false, message: "No matching policy found. Please check your details." });
            }
        })
        .catch(e => {
            console.error("Error verifying policy against AWS:", e);
            res.status(500).json({ success: false, message: "Internal Server Error" });
        });
});

// GET /api/policies - Retrieve all policies (for admin/testing)
router.get('/', async (req, res) => {
    try {
        const policies = await getAllPoliciesDB();
        res.status(200).json(policies);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST /api/policies/renew-check - Check if policy is eligible for renewal
router.post('/renew-check', (req, res) => {
    const { policyNumber, mobile } = req.body;

    if (!policyNumber || !mobile) {
        return res.status(400).json({ success: false, message: "Policy Number and Mobile are required" });
    }

    // Fetch all policies from DynamoDB first
    getAllPoliciesDB()
        .then(policies => {
            const policy = policies.find(p =>
                (p.policyId === policyNumber || p.policyId === policyNumber.trim()) &&
                (p.mobile === mobile || p.mobile === mobile.trim())
            );

            if (policy) {
                // Calculate dummy renewal premium (e.g., base it on existing premium or random for demo)
                const basePremium = parseInt(policy.premium || "5000");
                const renewalPremium = Math.round(basePremium * 1.05); // 5% increase for renewal

                // Calculate new dates
                const currentExpiry = new Date(); // assume it expires today for demo
                currentExpiry.setFullYear(currentExpiry.getFullYear() + 1);
                const newExpiryDate = currentExpiry.toLocaleDateString();

                res.json({
                    success: true,
                    message: "Policy Found",
                    policy: {
                        ...policy,
                        renewalPremium: renewalPremium,
                        newExpiryDate: newExpiryDate
                    }
                });
            } else {
                res.status(404).json({ success: false, message: "No matching policy found for renewal." });
            }
        })
        .catch(e => {
            console.error("Error checking renewal policy against AWS:", e);
            res.status(500).json({ success: false, message: "Internal Server Error" });
        });
});

module.exports = router;

document.addEventListener('DOMContentLoaded', () => {

    // --- Dynamic Content Initialization ---
    async function initDynamicContent() {
        try {
            const res = await fetch('/api/config');
            if (!res.ok) return;
            const config = await res.json();

            // Apply Logo globally
            if (config.logoUrl) {
                const logos = document.querySelectorAll('.logo-img');
                logos.forEach(img => {
                    img.src = config.logoUrl;
                    img.style.display = 'block';
                });
                const logoTexts = document.querySelectorAll('.logo-text');
                logoTexts.forEach(txt => txt.style.display = 'none');
            }

            // Apply Hero Changes (if on homepage)
            if (config.heroConfig) {
                const heroCov = document.getElementById('dynamic-hero-coverage');
                const heroPrice = document.getElementById('dynamic-hero-price');
                if (heroCov && config.heroConfig.coverage) heroCov.innerText = config.heroConfig.coverage;
                if (heroPrice && config.heroConfig.price) heroPrice.innerText = config.heroConfig.price;
            }

            // Inject Custom Sections for current page
            if (config.customSections && config.customSections.length > 0) {
                const currentPage = window.location.pathname.split('/').pop() || 'index.html';

                config.customSections.forEach(section => {
                    if (section.targetPage === currentPage || section.targetPage === '*') {
                        const container = document.getElementById(section.containerId);
                        if (container) {
                            container.innerHTML = section.htmlContent;
                        }
                    }
                });
            }

        } catch (e) {
            console.error("Failed to load dynamic config", e);
        }
    }
    initDynamicContent();

    // --- Sticky Header Logic ---
    const header = document.querySelector('.header');

    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.style.boxShadow = '0 10px 20px rgba(0,0,0,0.1)';
            header.style.padding = '10px 0';
        } else {
            header.style.boxShadow = '0 4px 6px rgba(0,0,0,0.05)';
            header.style.padding = '15px 0';
        }
    });

    // --- Mobile Menu ---
    const mobileToggle = document.querySelector('.mobile-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeMenu = document.querySelector('.close-menu');

    mobileToggle.addEventListener('click', () => {
        mobileMenu.classList.add('active');
    });

    closeMenu.addEventListener('click', () => {
        mobileMenu.classList.remove('active');
    });

    // --- Modal Logic (Quote & Calculator) ---
    const quoteModal = document.getElementById('quote-modal');
    const calcModal = document.getElementById('calc-modal');
    const openQuoteBtns = document.querySelectorAll('#open-quote-modal'); // Assuming multiple triggers eventually
    const closeButtons = document.querySelectorAll('.close-modal');
    const calcCards = document.querySelectorAll('.calc-card');

    function openModal(modal) {
        modal.style.display = 'flex';
    }

    function closeModal(modal) {
        modal.style.display = 'none';
    }

    // Trigger Quote Modal
    openQuoteBtns.forEach(btn => {
        btn.addEventListener('click', () => openModal(quoteModal));
    });

    // Trigger Calculator Modal
    calcCards.forEach(card => {
        card.addEventListener('click', (e) => {
            const type = card.dataset.type;
            const title = card.querySelector('span').innerText;
            document.getElementById('calc-title').innerText = title;
            // Reset fields for demo
            document.getElementById('calc-output').innerText = '₹ 0';
            openModal(calcModal);
        });
    });

    // Close Modals
    closeButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            closeModal(e.target.closest('.modal-overlay'));
        });
    });

    // Close on outside click
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-overlay')) {
            closeModal(e.target);
        }
    });

    // --- Calculator Logic (Simple Investment Estimation) ---
    const calcAmount = document.getElementById('calc-amount');
    const calcDuration = document.getElementById('calc-duration');
    const durationVal = document.getElementById('duration-val');
    const calcOutput = document.getElementById('calc-output');
    const calcBtn = document.getElementById('calc-btn');

    if (calcAmount && calcDuration && durationVal && calcOutput && calcBtn) {
        calcDuration.addEventListener('input', (e) => {
            durationVal.innerText = `${e.target.value} Years`;
        });

        calcBtn.addEventListener('click', () => {
            const p = parseFloat(calcAmount.value);
            const r = 0.12 / 12; // estimating 12% annual return
            const n = parseFloat(calcDuration.value) * 12;

            // SIP Formula: P × ({[1 + i]^n - 1} / i) × (1 + i)
            if (p > 0 && n > 0) {
                const fv = p * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
                calcOutput.innerText = `₹ ${Math.round(fv).toLocaleString()}`;
            } else {
                calcOutput.innerText = "Invalid Input";
            }
        });
    }

    // --- Promo Scroll Logic ---
    const promoWalk = 300; // scroll amount
    const scrollContainer = document.querySelector('.promo-cards-wrapper');
    const leftBtn = document.getElementById('scroll-left');
    const rightBtn = document.getElementById('scroll-right');

    if (scrollContainer && leftBtn && rightBtn) {
        leftBtn.addEventListener('click', () => {
            scrollContainer.scrollBy({ left: -promoWalk, behavior: 'smooth' });
        });

        rightBtn.addEventListener('click', () => {
            scrollContainer.scrollBy({ left: promoWalk, behavior: 'smooth' });
        });
    }

    // --- Testimonial Carousel ---
    const track = document.getElementById('testimonial-track');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const playPauseBtn = document.getElementById('play-pause-btn');
    const cards = document.querySelectorAll('.testimonial-card');

    if (track && prevBtn && nextBtn && playPauseBtn && cards.length > 0) {
        let currentIndex = 0;
        let isPlaying = true;
        let intervalId;

        function updateCarousel() {
            const cardWidth = cards[0].offsetWidth + 20; // card width + gap (approx)
            track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
        }

        function nextSlide() {
            currentIndex = (currentIndex + 1) % cards.length;
            updateCarousel();
        }

        function prevSlide() {
            currentIndex = (currentIndex - 1 + cards.length) % cards.length;
            updateCarousel();
        }

        function startAutoSlide() {
            intervalId = setInterval(nextSlide, 3000);
            playPauseBtn.innerHTML = '<i class="fas fa-pause"></i>';
            isPlaying = true;
        }

        function stopAutoSlide() {
            clearInterval(intervalId);
            playPauseBtn.innerHTML = '<i class="fas fa-play"></i>';
            isPlaying = false;
        }

        nextBtn.addEventListener('click', () => {
            nextSlide();
            if (isPlaying) { stopAutoSlide(); startAutoSlide(); } // Reset timer
        });

        prevBtn.addEventListener('click', () => {
            prevSlide();
            if (isPlaying) { stopAutoSlide(); startAutoSlide(); }
        });

        playPauseBtn.addEventListener('click', () => {
            if (isPlaying) {
                stopAutoSlide();
            } else {
                startAutoSlide();
            }
        });

        // Initialize
        startAutoSlide();
    }

    // --- Payment Page Logic ---
    const timerElement = document.getElementById('timer');
    const paymentTabs = document.querySelectorAll('.tab-item');
    const paymentSections = document.querySelectorAll('.mode-section');
    const paySecurelyBtn = document.getElementById('pay-securely-btn');

    // 1. Session Timer
    if (timerElement) {
        let time = 15 * 60; // 15 minutes in seconds

        const updateTimer = () => {
            const minutes = Math.floor(time / 60);
            let seconds = time % 60;

            seconds = seconds < 10 ? '0' + seconds : seconds;
            timerElement.innerText = `${minutes}:${seconds}`;

            if (time > 0) {
                time--;
            } else {
                // Timer expired
                clearInterval(timerInterval);
                alert("Session Expired. Please refresh.");
            }
        };

        const timerInterval = setInterval(updateTimer, 1000);
        updateTimer(); // Initial call
    }

    // 2. Tab Switching
    if (paymentTabs.length > 0 && paymentSections.length > 0) {
        paymentTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Remove active class from all tabs
                paymentTabs.forEach(t => t.classList.remove('active'));
                // Add active to clicked
                tab.classList.add('active');

                // Hide all sections
                paymentSections.forEach(sec => sec.classList.remove('active'));

                // Show target section
                const targetId = tab.getAttribute('data-target');
                const targetSection = document.getElementById(targetId);
                if (targetSection) {
                    targetSection.classList.add('active');
                }
            });
        });
    }

    // 3. Bank Selection Logic
    const bankGrid = document.getElementById('bank-grid');
    const bankDropdown = document.getElementById('bank-dropdown');
    let selectedBank = null;

    if (bankGrid && bankDropdown && paySecurelyBtn) {
        // Grid Selection
        const bankOptions = bankGrid.querySelectorAll('.bank-option');
        bankOptions.forEach(option => {
            option.addEventListener('click', () => {
                // Clear previous
                bankOptions.forEach(el => el.classList.remove('selected'));
                bankDropdown.value = ""; // Clear dropdown

                // Select new
                option.classList.add('selected');
                selectedBank = option.dataset.bank;
                paySecurelyBtn.innerText = `Pay Securely via ${selectedBank} ₹12,840`;
            });
        });

        // Dropdown Selection
        bankDropdown.addEventListener('change', (e) => {
            // Clear grid
            bankOptions.forEach(el => el.classList.remove('selected'));
            selectedBank = e.target.value;

            if (selectedBank) {
                paySecurelyBtn.innerText = `Pay Securely via ${selectedBank} ₹12,840`;
            } else {
                paySecurelyBtn.innerText = `Pay Securely ₹12,840`;
            }
        });

        paySecurelyBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const originalText = paySecurelyBtn.innerText;
            paySecurelyBtn.innerText = "Processing...";

            setTimeout(() => {
                // Determine Plan Duration (Default 1 Year if not found)
                const planData = JSON.parse(localStorage.getItem('selectedPlan')) || {};
                const userData = JSON.parse(localStorage.getItem('proposalData')) || {};

                // Calculate Dates
                const startDate = new Date();
                const endDate = new Date();
                const durationYears = planData.duration || 1; // Default 1 year
                endDate.setFullYear(startDate.getFullYear() + durationYears);

                // Format Dates (DD/MM/YYYY)
                const formatDate = (d) => d.toLocaleDateString('en-IN');

                // Construct WhatsApp Message
                const mobile = userData.mobile || "Your Registered Number";
                const msg = `✅ *Policy Issued!* \n\n📅 Start: ${formatDate(startDate)}\n📅 Exp: ${formatDate(endDate)}\n\nYour protection timeline has started. Track it on the ClaimEasy App.`;

                // Simulate WhatsApp Notification (Console/Alert for now, but UI shows it too)
                // alert(`[WhatsApp sent to ${mobile}]:\n${msg}`); 

                // Populate Success Modal
                document.getElementById('policy-start-date').innerText = formatDate(startDate);
                document.getElementById('policy-end-date').innerText = formatDate(endDate);
                document.getElementById('policy-duration-text').innerText = `${durationYears} Year(s) Protection Plan`;
                document.getElementById('user-mobile').innerText = mobile;

                // Show Modal
                const successModal = document.getElementById('payment-success-modal');
                successModal.style.display = 'flex';

                paySecurelyBtn.innerText = originalText;

            }, 2000);
        });
    }

    // --- Helper function for SMS Simulation (to be used by other payment methods) ---


    // 6. Proposer Details Collapsible
    const coll = document.getElementsByClassName("collapsible");
    for (let i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function () {
            this.classList.toggle("active");
            const content = this.nextElementSibling;
            if (content.style.display === "block") {
                content.style.display = "none";
            } else {
                content.style.display = "block";
            }
        });
    }

    // --- Quote Modal Logic ---
    const quoteForm = document.getElementById('quote-form');
    if (quoteForm) {
        quoteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = quoteForm.querySelector('button');
            const originalText = btn.innerText;
            btn.innerText = 'Processing...';
            btn.disabled = true;

            const formData = {
                type: 'Quick Quote',
                name: quoteForm.querySelector('input[type="text"]').value,
                mobile: quoteForm.querySelector('input[type="tel"]').value,
                status: 'Lead Generated'
            };

            try {
                const response = await fetch('http://15.207.72.245:5000/api/policies', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    alert('Quote requested successfully! Our experts will call you shortly.');
                    closeModal(document.getElementById('quote-modal'));
                    quoteForm.reset();
                } else {
                    alert('Something went wrong. Please try again.');
                }
            } catch (error) {
                console.error(error);
                alert('Backend connection error.');
            } finally {
                btn.innerText = originalText;
                btn.disabled = false;
            }
        });
    }

});

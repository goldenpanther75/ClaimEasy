const express = require('express');
const router = express.Router();
const { createUserDB, getAllUsersDB } = require('../services/awsService');

// Temporary storage for OTPs (in memory)
const otpStore = {};

// Generate and Send OTP
router.post('/send-otp', (req, res) => {
    const { identifier } = req.body; // Phone or Email

    if (!identifier) {
        return res.status(400).json({ message: 'Identifier (phone or email) is required' });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Store OTP with expiration (5 minutes)
    otpStore[identifier] = {
        otp,
        expires: Date.now() + 5 * 60 * 1000
    };

    console.log(`============================================`);
    console.log(`OTP for ${identifier}: ${otp}`);
    console.log(`============================================`);

    res.json({ message: 'OTP sent successfully', success: true, otp: otp });
});

// Verify OTP
router.post('/verify-otp', async (req, res) => {
    const { identifier, otp } = req.body;

    if (!identifier || !otp) {
        return res.status(400).json({ message: 'Identifier and OTP are required' });
    }

    const storedData = otpStore[identifier];

    if (!storedData) {
        return res.status(400).json({ message: 'OTP not requested or expired', success: false });
    }

    if (Date.now() > storedData.expires) {
        delete otpStore[identifier];
        return res.status(400).json({ message: 'OTP expired', success: false });
    }

    if (storedData.otp !== otp) {
        return res.status(400).json({ message: 'Invalid OTP', success: false });
    }

    try {
        // OTP Verified. Check if user exists in AWS DynamoDB.
        const users = await getAllUsersDB();
        const existingUser = users.find(u => u.phone === identifier || u.email === identifier);

        // Clear OTP after success
        delete otpStore[identifier];

        if (existingUser) {
            return res.json({
                success: true,
                isNewUser: false,
                user: existingUser,
                token: 'mock-jwt-token-' + Date.now()
            });
        } else {
            return res.json({
                success: true,
                isNewUser: true,
                token: 'mock-temp-token-' + Date.now()
            });
        }
    } catch (err) {
        console.error("AWS Error verifying OTP user status: ", err);
        return res.status(500).json({ message: 'Internal Server Error during OTP verification' });
    }
});

// Register User
router.post('/register', async (req, res) => {
    const { name, phone, email, dob, gender, address } = req.body;

    if (!name || (!phone && !email)) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    try {
        const users = await getAllUsersDB();

        // Check duplication
        const duplicate = users.find(u => (phone && u.phone === phone) || (email && u.email === email));
        if (duplicate) {
            return res.status(400).json({ message: 'User already exists', success: false });
        }

        const newUser = {
            name,
            phone,
            email,
            dob,
            gender,
            address, // Save address object
        };

        const result = await createUserDB(newUser); // Saves user to the Cloud

        res.json({
            success: true,
            user: result.user,
            message: 'Registration successful'
        });
    } catch (err) {
        console.error("AWS DynamoDB Error registering User:", err);
        res.status(500).json({ success: false, message: 'Internal Server Database Error' });
    }
});

module.exports = router;

const AWS = require('aws-sdk');

// Configure AWS with environment variables (the SDK automatically reads from ~/.aws/credentials if no explicit keys are provided,
// since we just ran `aws configure` it will use those credentials and region natively)
AWS.config.update({
    region: 'ap-south-1' // We explicitly lock this to Mumbai as requested by the user
});

const dynamodb = new AWS.DynamoDB.DocumentClient();

const POLICIES_TABLE = 'ClaimEasy_Policies';
const CLAIMS_TABLE = 'ClaimEasy_Claims';

// --- Policies ---

async function createPolicyDB(policyData) {
    const policyId = 'POL' + Date.now();
    const params = {
        TableName: POLICIES_TABLE,
        Item: {
            ...policyData,
            policyId: policyId,
            createdAt: new Date().toISOString()
        }
    };

    try {
        await dynamodb.put(params).promise();
        return { success: true, policyId: policyId, message: "Policy created successfully in DynamoDB" };
    } catch (error) {
        console.error("Error creating policy in AWS DynamoDB:", error);
        throw error;
    }
}

async function getPolicyByIdDB(policyId) {
    const params = {
        TableName: POLICIES_TABLE,
        Key: { policyId: policyId }
    };

    try {
        const result = await dynamodb.get(params).promise();
        return result.Item || null;
    } catch (error) {
        console.error("Error fetching policy from AWS DynamoDB:", error);
        throw error;
    }
}

async function getAllPoliciesDB() {
    const params = {
        TableName: POLICIES_TABLE
    };

    try {
        const result = await dynamodb.scan(params).promise();
        return result.Items || [];
    } catch (error) {
        console.error("Error fetching all policies from AWS DynamoDB:", error);
        throw error;
    }
}

async function updatePolicyDB(policyId, updateData) {
    const params = {
        TableName: POLICIES_TABLE,
        Item: {
            ...updateData,
            policyId: policyId,
            updatedAt: new Date().toISOString()
        }
    };
    try {
        await dynamodb.put(params).promise();
        return { success: true, message: "Policy updated successfully in DynamoDB" };
    } catch (error) {
        console.error("Error updating policy in AWS DynamoDB:", error);
        throw error;
    }
}

async function deletePolicyDB(policyId) {
    const params = {
        TableName: POLICIES_TABLE,
        Key: { policyId: policyId }
    };
    try {
        await dynamodb.delete(params).promise();
        return { success: true, message: "Policy deleted successfully from DynamoDB" };
    } catch (error) {
        console.error("Error deleting policy from AWS DynamoDB:", error);
        throw error;
    }
}

// --- Claims ---

async function createClaimDB(claimData) {
    const claimId = 'CLM' + Date.now();
    const params = {
        TableName: CLAIMS_TABLE,
        Item: {
            ...claimData,
            claimId: claimId,
            status: "Pending",
            submittedAt: new Date().toISOString()
        }
    };

    try {
        await dynamodb.put(params).promise();
        return { success: true, claimId: claimId, message: "Claim submitted successfully to DynamoDB" };
    } catch (error) {
        console.error("Error creating claim in AWS DynamoDB:", error);
        throw error;
    }
}

async function getClaimByIdDB(claimId) {
    const params = {
        TableName: CLAIMS_TABLE,
        Key: { claimId: claimId }
    };

    try {
        const result = await dynamodb.get(params).promise();
        return result.Item || null;
    } catch (error) {
        console.error("Error fetching claim from AWS DynamoDB:", error);
        throw error;
    }
}

async function getAllClaimsDB() {
    const params = {
        TableName: CLAIMS_TABLE
    };

    try {
        const result = await dynamodb.scan(params).promise();
        return result.Items || [];
    } catch (error) {
        console.error("Error fetching all claims from AWS DynamoDB:", error);
        throw error;
    }
}

async function updateClaimDB(claimId, updateData) {
    const params = {
        TableName: CLAIMS_TABLE,
        Item: {
            ...updateData,
            claimId: claimId,
            updatedAt: new Date().toISOString()
        }
    };
    try {
        await dynamodb.put(params).promise();
        return { success: true, message: "Claim updated successfully in DynamoDB" };
    } catch (error) {
        console.error("Error updating claim in AWS DynamoDB:", error);
        throw error;
    }
}

const USERS_TABLE = 'ClaimEasy_Users';

// --- Users ---

async function createUserDB(userData) {
    // Generate ID if not provided, else use phone or email as primary string
    const userId = userData.id || Date.now().toString();
    const params = {
        TableName: USERS_TABLE,
        Item: {
            ...userData,
            id: userId,
            createdAt: new Date().toISOString()
        }
    };

    try {
        await dynamodb.put(params).promise();
        return { success: true, user: params.Item, message: "User created successfully in DynamoDB" };
    } catch (error) {
        console.error("Error creating user in AWS DynamoDB:", error);
        throw error;
    }
}

async function getAllUsersDB() {
    const params = {
        TableName: USERS_TABLE
    };

    try {
        const result = await dynamodb.scan(params).promise();
        return result.Items || [];
    } catch (error) {
        console.error("Error fetching all users from AWS DynamoDB:", error);
        throw error;
    }
}


module.exports = {
    createPolicyDB,
    getPolicyByIdDB,
    getAllPoliciesDB,
    updatePolicyDB,
    deletePolicyDB,
    createClaimDB,
    getClaimByIdDB,
    getAllClaimsDB,
    updateClaimDB,
    createUserDB,
    getAllUsersDB
};

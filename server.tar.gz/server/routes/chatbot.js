const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const claimsFile = path.join(__dirname, '../data/claims.json');

// --- Helper: Read JSON ---
const getClaims = () => {
    try {
        if (!fs.existsSync(claimsFile)) return [];
        return JSON.parse(fs.readFileSync(claimsFile, 'utf8'));
    } catch (err) { return []; }
};

// POST /api/chat - Chatbot interaction
router.post('/', async (req, res) => {
    try {
        const { message, context } = req.body; // Context contains page info
        const cleanMsg = message.trim().toLowerCase();

        // --- SECURITY GUARDRAIL ---
        // Block queries asking for internal, sensitive, or personal info
        const blocklist = ['admin', 'password', 'database', 'user ', 'users', 'personal', 'credential', 'hack', 'login'];
        if (blocklist.some(word => cleanMsg.includes(word))) {
            return res.json({
                response: "I cannot provide personal information, admin details, or database records. This information is highly classified and restricted to authorized personnel only."
            });
        }

        // --- Context Awareness Check ---
        let contextHint = '';
        if (context && context.product) {
            contextHint = context.product;
        } else if (context && context.page) {
            if (context.page.includes('car')) contextHint = 'car';
            if (context.page.includes('bike')) contextHint = 'bike';
            if (context.page.includes('health')) contextHint = 'health';
            if (context.page.includes('travel')) contextHint = 'travel';
            if (context.page.includes('term')) contextHint = 'term';
            if (context.page.includes('home')) contextHint = 'home';
        }

        // --- DYNAMIC PRODUCT & BUDGET FLOW ---
        const products = ['car', 'bike', 'health', 'travel', 'term', 'home'];

        let detectedProduct = contextHint || '';
        for (let p of products) {
            if (cleanMsg.includes(p)) {
                detectedProduct = p;
                break;
            }
        }

        const compLinks = {
            'car': 'car_comparison.html',
            'bike': 'bike_comparison.html',
            'health': 'health_comparison.html',
            'travel': 'travel_comparison.html',
            'term': 'TermLife_comparison.html',
            'home': 'home_comparison.html'
        };

        const standardLinks = {
            'car': 'car_insurance.html',
            'bike': 'bike_insurance.html',
            'health': 'health_insurance.html',
            'travel': 'travel_insurance.html',
            'term': 'TermLife.html',
            'home': 'home_insurance.html',
            'insurance': 'index.html'
        };

        // 1. Detect if User Provided a Budget (Numeric values >= 100 to filter out typos like '2 buy')
        const budgetNumbers = (cleanMsg.match(/\d+/g) || []).map(Number).filter(n => n >= 100);
        const hasBudgetKeyword = cleanMsg.includes('budget') || cleanMsg.includes('under') || cleanMsg.includes('range');

        if (budgetNumbers.length > 0 || hasBudgetKeyword) {
            let budgetParam = 2500; // Default fallback
            if (budgetNumbers.length > 0) {
                budgetParam = Math.max(...budgetNumbers); // Take the upper bound of the range
            }

            const product = detectedProduct || 'car'; // Fallback
            const compLink = compLinks[product] || 'car_comparison.html';

            return res.json({
                response: `Perfect! Redirecting you to the ${product} insurance comparison page to view plans within your budget.<br><br><a href='${compLink}?budget=${budgetParam}' class='chat-chip' style='display:inline-block; text-align:center;'>View ${product.charAt(0).toUpperCase() + product.slice(1)} Plans Under ₹${budgetParam}</a>`,
                detectedProduct: product
            });
        }

        // 2. Detect Purchase/Quote Intent (No Budget Provided Yet)
        const buyIntent = cleanMsg.includes('quote') || cleanMsg.includes('buy') || cleanMsg.includes('price') || cleanMsg.includes('purchase') || cleanMsg.includes('apply');

        // 3. Detect standalone product mention (e.g. "home insurance")
        const productOnlyIntent = products.some(p => cleanMsg === p || cleanMsg === `${p} insurance` || cleanMsg === `i want ${p} insurance`);

        if (buyIntent || productOnlyIntent) {
            if (!detectedProduct) {
                return res.json({
                    response: "What type of insurance are you looking to purchase? (e.g., car, health, life, home, bike, travel)",
                    detectedProduct: detectedProduct
                });
            } else {
                return res.json({
                    response: `Great! What’s your monthly premium budget range for <strong>${detectedProduct} insurance</strong>? (e.g., 500 to 1000, Under 2500)`,
                    detectedProduct: detectedProduct
                });
            }
        }

        // 4. Inquire about general Details/Information
        const infoIntent = cleanMsg.includes('detail') || cleanMsg.includes('info') || cleanMsg.includes('premium') || cleanMsg.includes('cover') || cleanMsg.includes('benefit') || cleanMsg.includes('about');

        if (infoIntent && detectedProduct) {
            const knowledgeBase = {
                'car': { premium: '₹850', sum: '₹48,000 IDV', feature: 'Zero Depreciation & 3000+ Garages' },
                'bike': { premium: '₹450', sum: '₹30,000 IDV', feature: 'Roadside Assistance & Instant Policy' },
                'health': { premium: '₹600', sum: '₹4 Crores', feature: 'No Co-pay & Restoration Benefit' },
                'travel': { premium: '₹950', sum: '₹50 Lakhs', feature: 'Medical Evacuation & Flight Delay' },
                'term': { premium: '₹380', sum: '₹2 Crores', feature: 'Waiver of Premium & Critical Illness' },
                'home': { premium: '₹500', sum: '₹50 Lakhs', feature: 'Fire, Burglary & Earthquake Cover' }
            };

            const kb = knowledgeBase[detectedProduct];
            if (kb) {
                const compLink = compLinks[detectedProduct] || 'index.html';
                return res.json({
                    response: `Here is a quick overview of our <strong>${detectedProduct} insurance</strong>:<br><br>
                    <ul style="padding-left: 20px; line-height: 1.6; margin-bottom: 15px;">
                        <li><strong>Starting Premium:</strong> ${kb.premium}/month</li>
                        <li><strong>Max Coverage:</strong> ${kb.sum}</li>
                        <li><strong>Key Benefits:</strong> ${kb.feature}</li>
                    </ul>
                    <a href='${compLink}' class='chat-chip' style='display:inline-block; text-align:center;'>Compare All ${detectedProduct.charAt(0).toUpperCase() + detectedProduct.slice(1)} Plans</a>`,
                    detectedProduct: detectedProduct
                });
            }
        }

        if (cleanMsg.includes('autosecure') || cleanMsg.includes('auto secure') || cleanMsg.includes('auto-secure') || cleanMsg.includes('value drive') || cleanMsg.includes('city guardian')) {
            return res.json({
                response: "Perfect! Redirecting you to the policy purchase page.<br><br><a href='car_insurance.html' class='chat-chip' style='display:inline-block; text-align:center;'>Proceed to Apply</a>",
                detectedProduct: 'car'
            });
        }

        // --- Intent: File Claim ---
        if (cleanMsg.includes('file') || cleanMsg.includes('new claim') || cleanMsg.includes('register claim')) {
            return res.json({
                response: `To file a new claim, please visit our <strong>Claim Assistance</strong> page.
                <br><br>
                <div class="chat-options">
                    <a href="health_easyclaim.html" class="chat-chip">File Health Claim</a>
                    <a href="car_easyclaim.html" class="chat-chip">File Car Claim</a>
                    <a href="claim_intimation.html" class="chat-chip">Other Claims</a>
                </div>`
            });
        }

        // --- Intent: Check Status (with ID) ---
        // Match: CLM123, clm 123, claim id 123
        const idMatch = cleanMsg.match(/(?:clm|claim id)[\s-]*(\d+)/i);

        if (idMatch) {
            const numericId = idMatch[1];
            // Admin/Claims APIs generate IDs like "CLM" + Date.now() (e.g., CLM170000...)
            // We search for that exact string.
            const targetId = `CLM${numericId}`;

            const claims = getClaims();

            // Search: Exact Match or if user provided loose ID
            // Also handle case where user typed "CLM-123" but we store "CLM123"
            const claim = claims.find(c => c.id === targetId || c.id === `CLM-${numericId}` || c.id === numericId);

            if (claim) {
                let statusColor = 'orange';
                if (claim.status === 'Approved') statusColor = 'green';
                if (claim.status === 'Rejected') statusColor = 'red';
                if (claim.status === 'Settled') statusColor = '#0065ff';

                return res.json({
                    response: `Here are the details for <strong>${claim.id}</strong>:<br>
                    <div style="background:#f5f5f5; padding:10px; border-radius:8px; margin-top:5px;">
                        Status: <span style="color:${statusColor}; font-weight:bold">${claim.status}</span><br>
                        Amount: <strong>₹${claim.amount || 'N/A'}</strong><br>
                        Date: ${new Date(claim.submittedAt || claim.createdAt).toLocaleDateString()}
                    </div>`
                });
            } else {
                return res.json({
                    response: `I couldn't find a claim with ID <strong>${targetId}</strong>.<br>Please check the ID and try again, or contact support.`
                });
            }
        }

        // --- Intent: Check Status (without ID) ---
        if (cleanMsg.includes('status') || cleanMsg.includes('track')) {
            return res.json({
                response: "I can check that for you. Please provide your <strong>Claim ID</strong> (e.g., CLM123456)."
            });
        }

        // --- Intent: Support/Help ---
        if (cleanMsg.includes('help') || cleanMsg.includes('support') || cleanMsg.includes('contact')) {
            return res.json({
                response: "Our support team is available 24/7.<br>📞 <strong>1800-258-5956</strong><br>📧 <strong>care@claimeasy.com</strong>"
            });
        }

        // --- Default / Greeting ---
        if (cleanMsg.includes('hi') || cleanMsg.includes('hello')) {
            return res.json({
                response: "Hello! I am ClaimEasy Assistant, a smart insurance concierge for ClaimEasy.<br><br>I can help you purchase insurance, file claims, and explore policies. How can I assist you today?",
                showOptions: true // Frontend can check this to show standard chips
            });
        }

        // Fallback
        return res.json({
            response: "I understand simple requests like:<br>• 'File a claim'<br>• 'Check status of CLM123...'<br>• 'Contact Support'"
        });

    } catch (error) {
        console.error("Chatbot Error:", error);
        res.status(500).json({ error: "Server error." });
    }
});

module.exports = router;
